import threading
import time
import random

BUFFER_SIZE = 5
buffer = []
empty_slots = threading.Semaphore(BUFFER_SIZE)
full_slots = threading.Semaphore(0)
mutex = threading.Semaphore(1)

def producer():
    while True:
        item = random.randint(1, 100)
        empty_slots.acquire()
        mutex.acquire()
        buffer.append(item)
        print(f"Producer produced: {item}, Buffer: {buffer}")
        mutex.release()
        full_slots.release()
        time.sleep(random.uniform(0.1, 0.5))

def consumer():
    while True:
        full_slots.acquire()
        mutex.acquire()
        item = buffer.pop(0)
        print(f"Consumer consumed: {item}, Buffer: {buffer}")
        mutex.release()
        empty_slots.release()
        time.sleep(random.uniform(0.1, 0.5))

if __name__ == "__main__":
    producer_thread = threading.Thread(target=producer)
    consumer_thread = threading.Thread(target=consumer)

    producer_thread.start()
    consumer_thread.start()

    producer_thread.join()
    consumer_thread.join()



'''

Initialize shared variables and semaphores:

BUFFER_SIZE: The size of the buffer (number of slots).
buffer: The shared buffer where the producer produces and the consumer consumes items.
empty_slots: A semaphore initialized to BUFFER_SIZE, representing the number of empty slots in the buffer.
full_slots: A semaphore initialized to 0, representing the number of filled slots in the buffer.
mutex: A binary semaphore initialized to 1, used for mutual exclusion when modifying the buffer.
Implement the producer function:

Inside an infinite loop, the producer generates a new item.
It acquires the empty_slots semaphore to ensure there is an empty slot to produce an item.
It acquires the mutex semaphore to ensure exclusive access to the buffer while adding the item.
The item is appended to the buffer, and a message is printed indicating the produced item and the current buffer state.
The mutex semaphore is released to allow other threads access to the buffer.
The full_slots semaphore is released to indicate that there is one more filled slot in the buffer.
The producer thread then sleeps for a random interval.
Implement the consumer function:

Inside an infinite loop, the consumer tries to acquire the full_slots semaphore to check if there is a filled slot in the buffer.
Once acquired, it acquires the mutex semaphore to ensure exclusive access to the buffer while consuming an item.
The consumer takes the first item from the buffer, removes it, and prints a message indicating the consumed item and the current buffer state.
The mutex semaphore is released to allow other threads access to the buffer.
The empty_slots semaphore is released to indicate that there is one more empty slot in the buffer.
The consumer thread then sleeps for a random interval.
Create two threads, one for the producer function and one for the consumer function.

Start the threads to begin the producer-consumer simulation.

The program will run indefinitely, with the producer producing items and adding them to the buffer while the consumer consumes items from the buffer. The semaphores ensure that the producer and consumer synchronize correctly to avoid race conditions and maintain the buffer's integrity.

'''