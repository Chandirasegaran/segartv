 
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Process {
    int process_id;
    int burst_time;
    int arrival_time;
    int priority;
    int waiting_time;
    int turnaround_time;
};

void calculate_waiting_turnaround_time(vector<Process>& processes) {
    int n = processes.size();
    vector<int> waiting_time(n, 0);
    vector<int> turnaround_time(n, 0);

    waiting_time[0] = 0;
    turnaround_time[0] = processes[0].burst_time;

    for (int i = 1; i < n; i++) {
        waiting_time[i] = processes[i - 1].burst_time + waiting_time[i - 1];
        turnaround_time[i] = processes[i].burst_time + waiting_time[i];
    }

    for (int i = 0; i < n; i++) {
        processes[i].waiting_time = waiting_time[i];
        processes[i].turnaround_time = turnaround_time[i];
    }
}

bool compare_arrival_time(const Process& p1, const Process& p2) {
    return p1.arrival_time < p2.arrival_time;
}

bool compare_burst_time(const Process& p1, const Process& p2) {
    return p1.burst_time < p2.burst_time;
}

bool compare_priority(const Process& p1, const Process& p2) {
    return p1.priority < p2.priority;
}

void fcfs(vector<Process>& processes) {
    sort(processes.begin(), processes.end(), compare_arrival_time);

    calculate_waiting_turnaround_time(processes);

    cout << "FCFS Scheduling:" << endl;
    cout << "Process ID\tBurst Time\tArrival Time\tWaiting Time\tTurnaround Time" << endl;
    for (const Process& process : processes) {
        cout << process.process_id << "\t\t" << process.burst_time << "\t\t" << process.arrival_time << "\t\t"
             << process.waiting_time << "\t\t" << process.turnaround_time << endl;
    }
    cout << endl;
}

void sjf(vector<Process>& processes) {
    sort(processes.begin(), processes.end(), compare_burst_time);

    calculate_waiting_turnaround_time(processes);

    cout << "SJF Scheduling:" << endl;
    cout << "Process ID\tBurst Time\tArrival Time\tWaiting Time\tTurnaround Time" << endl;
    for (const Process& process : processes) {
        cout << process.process_id << "\t\t" << process.burst_time << "\t\t" << process.arrival_time << "\t\t"
             << process.waiting_time << "\t\t" << process.turnaround_time << endl;
    }
    cout << endl;
}

void round_robin(vector<Process>& processes, int quantum) {
    int n = processes.size();
    vector<int> remaining_time(n);
    vector<int> waiting_time(n, 0);
    vector<int> turnaround_time(n, 0);
    int current_time = 0;
    int completed = 0;

    for (int i = 0; i < n; i++) {
        remaining_time[i] = processes[i].burst_time;
    }

    while (completed != n) {
        for (int i = 0; i < n; i++) {
            if (remaining_time[i] <= quantum && remaining_time[i] > 0) {
                current_time += remaining_time[i];
                remaining_time[i] = 0;
                waiting_time[i] = current_time - processes[i].burst_time;
                turnaround_time[i] = current_time;
                completed++;
            } else if (remaining_time[i] > 0) {
                current_time += quantum;
                remaining_time[i] -= quantum;
            }
        }
    }

    cout << "Round Robin Scheduling:" << endl;
    cout << "Process ID\tBurst Time\tArrival Time\tWaiting Time\tTurnaround Time" << endl;
    for (int i = 0; i < n; i++) {
        cout << processes[i].process_id << "\t\t" << processes[i].burst_time << "\t\t" << processes[i].arrival_time
             << "\t\t" << waiting_time[i] << "\t\t" << turnaround_time[i] << endl;
    }
    cout << endl;
}

void priority(vector<Process>& processes) {
    sort(processes.begin(), processes.end(), compare_priority);

    calculate_waiting_turnaround_time(processes);

    cout << "Priority Scheduling:" << endl;
    cout << "Process ID\tBurst Time\tArrival Time\tWaiting Time\tTurnaround Time" << endl;
    for (const Process& process : processes) {
        cout << process.process_id << "\t\t" << process.burst_time << "\t\t" << process.arrival_time << "\t\t"
             << process.waiting_time << "\t\t" << process.turnaround_time << endl;
    }
    cout << endl;
}

int main() {
    vector<Process> processes = {
        {1, 10, 0, 3},
        {2, 5, 1, 2},
        {3, 8, 2, 1},
        {4, 4, 3, 4},
        {5, 6, 4, 5}
    };

    fcfs(processes);
    sjf(processes);
    round_robin(processes, 2);
    priority(processes);

    return 0;
}
