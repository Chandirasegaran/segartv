def bankers_algorithm(available, max_required, allocated):
    processes = len(max_required)
    resources = len(available)
    need = [[max_required[i][j] - allocated[i][j] for j in range(resources)] for i in range(processes)]
    finish = [False] * processes
    safe_sequence = []

    while True:
        found = False
        for i in range(processes):
            if not finish[i] and all(need[i][j] <= available[j] for j in range(resources)):
                available = [available[j] + allocated[i][j] for j in range(resources)]
                finish[i] = True
                safe_sequence.append(i)
                found = True

        if not found:
            break

    if all(finish):
        return True, safe_sequence
    else:
        return False, []

# Example usage
if __name__ == "__main__":
    available_resources = [3, 3, 2]
    max_resources = [
        [7, 5, 3],
        [3, 2, 2],
        [9, 0, 2],
        [2, 2, 2],
        [4, 3, 3]
    ]
    allocated_resources = [
        [0, 1, 0],
        [2, 0, 0],
        [3, 0, 2],
        [2, 1, 1],
        [0, 0, 2]
    ]

    is_safe, safe_sequence = bankers_algorithm(available_resources, max_resources, allocated_resources)
    if is_safe:
        print("System is in safe state.")
        print("Safe sequence:", safe_sequence)
    else:
        print("System is in unsafe state.")
