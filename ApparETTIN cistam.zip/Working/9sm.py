# import threading
# import time
# import random

# def philosopher(name, left_fork, right_fork):
#     for _ in range(3):
#         thinking_time = random.uniform(0.5, 1.5)
#         print(f"{name} is thinking.")
#         time.sleep(thinking_time)
#         with left_fork, right_fork:
#             print(f"{name} starts eating.")
#             eating_time = random.uniform(0.5, 1.5)
#             time.sleep(eating_time)
#             print(f"{name} finishes eating.")

# forks = [threading.Semaphore(1) for _ in range(5)]
# philosophers = [threading.Thread(target=philosopher, args=(f"Philosopher {i}", forks[i], forks[(i+1) % 5])) for i in range(5)]
# for p in philosophers: p.start()
# for p in philosophers: p.join()
# print("Dinner is over.")

import threading
import time
import random

def philosopher(name, left_fork, right_fork):
    while True:
        thinking_time = random.uniform(0.5, 1.5)
        print(f"{name} is thinking.")
        time.sleep(thinking_time)
        with left_fork, right_fork:
            print(f"{name} starts eating.")
            eating_time = random.uniform(0.5, 1.5)
            time.sleep(eating_time)
            print(f"{name} finishes eating.")

forks = [threading.Semaphore(1) for _ in range(5)]
philosophers = [threading.Thread(target=philosopher, args=(f"Philosopher {i}", forks[i], forks[(i+1) % 5])) for i in range(5)]
for p in philosophers: p.start()
for p in philosophers: p.join()
