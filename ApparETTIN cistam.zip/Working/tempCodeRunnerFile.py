import threading
import time

class Philosopher(threading.Thread):
    def __init__(self, name, left_chopstick, right_chopstick):
        threading.Thread.__init__(self)
        self.name = name
        self.left_chopstick = left_chopstick
        self.right_chopstick = right_chopstick

    def run(self):
        while True:
            print(f"{self.name} is thinking.")
            time.sleep(2)  # Simulate thinking

            print(f"{self.name} is hungry and trying to pick up chopsticks.")
            self.dine()

    def dine(self):
        while True:
            self.left_chopstick.acquire()  # Acquire left chopstick
            locked = self.right_chopstick.acquire(False)  # Acquire right chopstick without blocking

            if locked:
                break

            self.left_chopstick.release()  # Release left chopstick
            print(f"{self.name} is waiting to pick up the right chopstick.")

        self.eat()
        self.left_chopstick.release()  # Release left chopstick
        self.right_chopstick.release()  # Release right chopstick

    def eat(self):
        print(f"{self.name} is eating.")
        time.sleep(2)  # Simulate eating

if __name__ == "__main__":
    num_philosophers = 5
    philosophers = []

    chopsticks = [threading.Lock() for _ in range(num_philosophers)]

    for i in range(num_philosophers):
        left_chopstick = chopsticks[i]
        right_chopstick = chopsticks[(i + 1) % num_philosophers]

        philosopher = Philosopher(f"Philosopher {i+1}", left_chopstick, right_chopstick)
        philosophers.append(philosopher)
        philosopher.start()

    # Wait for all philosophers to finish
    for philosopher in philosophers:
        philosopher.join()