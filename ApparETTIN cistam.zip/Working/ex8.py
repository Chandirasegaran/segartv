import threading
import time

BUFFER_SIZE = 5
buffer = []
mutex = threading.Semaphore(1)
empty = threading.Semaphore(BUFFER_SIZE)
full = threading.Semaphore(0)
items_to_produce = 10
items_produced = 0
items_consumed = 0

class Producer(threading.Thread):
    def run(self):
        global buffer, mutex, empty, full, items_to_produce, items_produced
        while items_produced < items_to_produce:
            time.sleep(1)  # Simulating production time
            empty.acquire()  # Wait if the buffer is full
            mutex.acquire()  # Acquire mutex to access the buffer
            buffer.append(items_produced)
            print(f"Producer {self.name} produced: Item {items_produced}")
            items_produced += 1
            mutex.release()  # Release mutex
            full.release()  # Notify the consumer that an item is available

class Consumer(threading.Thread):
    def run(self):
        global buffer, mutex, empty, full, items_to_produce, items_consumed
        while items_consumed < items_to_produce:
            time.sleep(2)  # Simulating consumption time
            full.acquire()  # Wait if the buffer is empty
            mutex.acquire()  # Acquire mutex to access the buffer
            item = buffer.pop(0)
            print(f"Consumer {self.name} consumed: Item {item}")
            items_consumed += 1
            mutex.release()  # Release mutex
            empty.release()  # Notify the producer that space is available

# Create producer and consumer threads
producer1 = Producer()
producer2 = Producer()
consumer1 = Consumer()
consumer2 = Consumer()

# Start the threads
producer1.start()
producer2.start()
consumer1.start()
consumer2.start()

# Wait for all threads to finish
producer1.join()
producer2.join()
consumer1.join()
consumer2.join()
