<!DOCTYPE html>
<html>
<head>
    <title>Simple Registration Form</title>
</head>
<body>

    <h1>Registration Form</h1>

    <form action="process.php" method="post">
        <label >Name:</label>
        <input type="text" id="name" required>
        <br>

        <label>Register Number:</label>
        <input type="text" id="registerNumber" required>
        <br>

        <input type="submit" value="Submit">
    </form>

</body>
</html>
