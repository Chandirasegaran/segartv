<?php
$connection = mysqli_connect("localhost:3306", "root", "2503", "external");
if ($_SERVER["REQUEST_METHOD"]=="POST")
{
    $name = $_POST["name"];
    $registerNumber = $_POST["registerNumber"];
    $sql="INSERT INTO studreg (studname, regno) VALUES ('$name','$registerNumber')";
    if (mysqli_query($connection, $sql)) {
        echo "Registration successful!";
    } 
    mysqli_close($connection);
}

?>