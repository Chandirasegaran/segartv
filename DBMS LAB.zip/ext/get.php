<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>get details</title>
</head>
<body>
    <form action="view.php" method="post">
        <label for="registerNumber">Register Number:</label>
        <input type="text" id="searchregno" name="searchregno" required>
        <br>
        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>
