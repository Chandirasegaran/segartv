<?php
$connection = mysqli_connect("localhost:3306", "root", "2503", "external");
$regno = $_POST['searchregno'];
$sql = "SELECT * FROM studreg WHERE regno = '$regno'";
$result = $connection->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view</title>
</head>
<body>
<?php
            if ($result->num_rows > 0) {
                // Display the ticket details
                while ($row = $result->fetch_assoc()) {
                    echo "<p>Name: " . $row['studname'] . "</p>";
                    echo "<p>Regno: " . $row['regno'] . "</p>";
                }
            } else {
                echo "Not found";
            }
            $connection->close();
            ?>
</body>
</html>