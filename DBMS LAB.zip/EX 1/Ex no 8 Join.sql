create database jointest;
use jointest;
drop database jointest;

CREATE TABLE branch (
branch_id INT PRIMARY KEY AUTO_INCREMENT,
br_name VARCHAR(30) NOT NULL,
addr VARCHAR(200) );

CREATE TABLE employee (
emp_id INT PRIMARY KEY AUTO_INCREMENT,
ename VARCHAR(30) NOT NULL,
salary INT,
branch_id INT,
CONSTRAINT FK_branchId FOREIGN KEY(branch_id) REFERENCES branch(branch_id)
);


INSERT INTO branch VALUES(1,"Chennai","16 ABC Road"),(2,"Coimbatore","120 15th Block"),(3,"Mumbai","25 XYZ Road"),(4,"Hydrabad","32 10th Street");
INSERT INTO employee (ename, salary, branch_id) VALUES  ('Segar', 50000, 1),  ('Mukesh', 45000, 2),  ('Arul', 60000, 1),  ('Sasi', 55000, 3),  ('Gopi', 48000, 2),  ('Meghaa', 52000, 1),(7,"Deerthana",54000,5);



-----------------
select *from employee
inner join branch on employee.branch_id=branch.branch_id;

select *from employee
right join branch on employee.branch_id=branch.branch_id;

select *from employee
left join branch on employee.branch_id=branch.branch_id;

select *from employee
right join branch on employee.branch_id=branch.branch_id
union
select *from employee
left join branch on employee.branch_id=branch.branch_id;

select *from employee
cross join branch ;

-----------------



-- Inner Join
SELECT employee.emp_id, employee.ename, employee.salary, branch.br_name
FROM employee
INNER JOIN branch ON employee.branch_id = branch.branch_id;

-- Left Join
SELECT employee.emp_id, employee.ename, employee.salary, branch.br_name
FROM employee
LEFT JOIN branch ON employee.branch_id = branch.branch_id;

-- Right Join
SELECT employee.emp_id, employee.ename, employee.salary, branch.br_name
FROM employee
RIGHT JOIN branch ON employee.branch_id = branch.branch_id;




-- Cross Join
SELECT employee.emp_id, employee.ename, employee.salary, branch.br_name
FROM employee
CROSS JOIN branch;

SELECT *FROM BRANCH;