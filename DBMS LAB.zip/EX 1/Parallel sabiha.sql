-- Create Students table
CREATE TABLE Students (
    student_id INT PRIMARY KEY identity(1,1),
    name VARCHAR(50),
    age INT,
    gender VARCHAR(10),
    contact_number VARCHAR(15),
    email VARCHAR(50),
    address VARCHAR(100),
    academic_records VARCHAR(100),
    preferences VARCHAR(100),
    counseling_status VARCHAR(50)
);
alter table Students alter column counseling_status Varchar(200);
ALTER TABLE Students ADD sid INT IDENTITY(1,1);

drop table Students;
drop table Matching;
drop table Colleges;
-- Create Colleges table
CREATE TABLE Colleges (
    college_id INT PRIMARY KEY identity(1,1),
    name VARCHAR(100),
    location VARCHAR(100),
    programs_offered VARCHAR(100),
    admission_criteria VARCHAR(100),
    faculty_details VARCHAR(200),
    infrastructure_details VARCHAR(200)
);

-- Create Matching table
CREATE TABLE Matching (
    student_id INT,
    college_id INT,
    match_score DECIMAL(5, 2),
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (college_id) REFERENCES Colleges(college_id)
);
drop table Matching;
-- Insert sample data into Students table
INSERT INTO Students ( name, age, gender, contact_number, email, address, academic_records, preferences, counseling_status)
VALUES
    ( 'John Smith', 18, 'Male', '123456789', 'john.smith@example.com', '123 Main St', 'GPA: 3.8, SAT: 1450', 'Location: Any, Specialization: Computer Science', 'Assigned: No'),
    ( 'Jane Doe', 17, 'Female', '987654321', 'jane.doe@example.com', '456 Elm St', 'GPA: 3.9, SAT: 1500', 'Location: East Coast, Specialization: Electrical Engineering', 'Assigned: No');

-- Insert sample data into Colleges table
INSERT INTO Colleges ( name, location, programs_offered, admission_criteria, faculty_details, infrastructure_details)
VALUES
    ( 'University of Engineering', 'West Coast', 'Computer Science, Electrical Engineering', 'Minimum GPA: 3.5, SAT: 1400', 'Faculty of Engineering: Prof. John Smith, Prof. Jane Doe', 'Advanced labs, Research facilities'),
    ( 'Tech Institute', 'East Coast', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.2, SAT: 1300', 'Faculty of Engineering: Prof. Alex Johnson, Prof. Sarah Williams', 'State-of-the-art campus, Engineering workshops');
	-- Insert additional records into Students table
INSERT INTO Students ( name, age, gender, contact_number, email, address, academic_records, preferences, counseling_status)
VALUES
   ( 'Sarah Johnson', 19, 'Female', '9876543210', 'sarahjohnson@example.com', '789 Oak St, City', 'GPA: 3.7, SAT: 1280', 'Location: City, Specialization: Civil Engineering', 'Assigned College: XYZ University, Counseling Round: 1'),
   ( 'Michael Brown', 18, 'Male', '5647382910', 'michaelbrown@example.com', '321 Pine St, Town', 'GPA: 3.6, SAT: 1370', 'Location: Town, Specialization: Mechanical Engineering', NULL);

-- Insert additional records into Colleges table
INSERT INTO Colleges ( name, location, programs_offered, admission_criteria, faculty_details, infrastructure_details)
VALUES
   ( 'DEF Institute', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1250', 'Faculty: Prof. Wilson, Prof. Thompson', 'Library, Labs'),
   ( 'GHI University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1300', 'Faculty: Prof. Davis, Prof. Moore', 'Research Center, Auditorium');
   -- Insert records into Students table
INSERT INTO Students ( name, age, gender, contact_number, email, address, academic_records, preferences, counseling_status)
VALUES
   ( 'Emily Wilson', 18, 'Female', '1234567890', 'emilywilson@example.com', '456 Elm St, City', 'GPA: 3.9, SAT: 1450', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Daniel Lee', 17, 'Male', '0987654321', 'daniellee@example.com', '789 Oak St, Town', 'GPA: 3.8, SAT: 1350', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Sophia Rodriguez', 19, 'Female', '5647382910', 'sophiarodriguez@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1320', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Oliver Martinez', 18, 'Male', '9876543210', 'olivermartinez@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1410', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Isabella Nguyen', 17, 'Female', '2468135790', 'isabellanguyen@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1380', 'Location: City, Specialization: Computer Science', NULL),
   ( 'William Kim', 18, 'Male', '9081726354', 'williamkim@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1500', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Ava Patel', 19, 'Female', '8192736450', 'avapatel@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1350', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'James Lee', 18, 'Male', '1029384756', 'jameslee@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1430', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Mia Lopez', 17, 'Female', '6574839201', 'mialopez@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1400', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Benjamin Chen', 18, 'Male', '1092837465', 'benjaminchen@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1480', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Ella Wong', 19, 'Female', '5463728190', 'ellawong@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1360', 'Location: City, Specialization: Civil Engineering', NULL);

-- Insert records into Colleges table
INSERT INTO Colleges ( name, location, programs_offered, admission_criteria, faculty_details, infrastructure_details)
VALUES
   ( 'JKL Institute', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1300', 'Faculty: Prof. Wilson, Prof. Thompson', 'Library, Labs'),
   ( 'MNO University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1350', 'Faculty: Prof. Davis, Prof. Moore', 'Research Center, Auditorium'),
   ( 'PQR College', 'City', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1380', 'Faculty: Prof. Harris, Prof. Adams', 'Library, Labs'),
   ( 'STU University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1400', 'Faculty: Prof. Clark, Prof. Lewis', 'Sports Complex, Auditorium'),
   ( 'VWX Institute', 'City', 'Computer Science, Electrical Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1320', 'Faculty: Prof. Turner, Prof. Evans', 'Library, Labs'),
   ( 'YZA University', 'Town', 'Civil Engineering, Mechanical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1360', 'Faculty: Prof. Reed, Prof. Parker', 'Research Center, Auditorium'),
   ( 'BCD College', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1400', 'Faculty: Prof. Morgan, Prof. Young', 'Library, Labs'),
   ( 'EFG University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1420', 'Faculty: Prof. King, Prof. Allen', 'Sports Complex, Auditorium'),
   ( 'HIJ Institute', 'City', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1350', 'Faculty: Prof. Hill, Prof. Watson', 'Library, Labs'),
   ( 'LMN University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1380', 'Faculty: Prof. Morris, Prof. Bell', 'Research Center, Auditorium');
      -- Insert records into Students table
INSERT INTO Students ( name, age, gender, contact_number, email, address, academic_records, preferences, counseling_status)
VALUES
   ('Liam Davis', 18, 'Male', '1234567890', 'liamdavis@example.com', '456 Elm St, City', 'GPA: 3.9, SAT: 1450', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Sophie Thompson', 17, 'Female', '0987654321', 'sophiethompson@example.com', '789 Oak St, Town', 'GPA: 3.8, SAT: 1350', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Noah Walker', 19, 'Male', '5647382910', 'noahwalker@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1320', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Emma Lewis', 18, 'Female', '9876543210', 'emmalewis@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1410', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Jackson Clark', 17, 'Male', '2468135790', 'jacksonclark@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1380', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Olivia Hall', 18, 'Female', '9081726354', 'oliviahall@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1500', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Aiden Moore', 19, 'Male', '8192736450', 'aidenmoore@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1350', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Mia Adams', 18, 'Female', '1029384756', 'miaadams@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1430', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Lucas Martin', 17, 'Male', '6574839201', 'lucasmartin@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1400', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Ava Turner', 18, 'Female', '1092837465', 'avaturner@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1480', 'Location: Town, Specialization: Electrical Engineering', NULL);
   -- Insert records into Colleges table
INSERT INTO Colleges ( name, location, programs_offered, admission_criteria, faculty_details, infrastructure_details)
VALUES
   ( 'OPQ College', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1300', 'Faculty: Prof. Wilson, Prof. Thompson', 'Library, Labs'),
   ( 'RST University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1350', 'Faculty: Prof. Davis, Prof. Moore', 'Research Center, Auditorium'),
   ( 'UVW College', 'City', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1380', 'Faculty: Prof. Harris, Prof. Adams', 'Library, Labs'),
   ( 'XYZ University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1400', 'Faculty: Prof. Clark, Prof. Lewis', 'Sports Complex, Auditorium'),
   ( 'BCD College', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1320', 'Faculty: Prof. Turner, Prof. Evans', 'Library, Labs'),
   ( 'EFG University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1360', 'Faculty: Prof. Reed, Prof. Parker', 'Research Center, Auditorium'),
   ( 'GHI Institute', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1400', 'Faculty: Prof. Morgan, Prof. Young', 'Library, Labs'),
   ( 'JKL University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1420', 'Faculty: Prof. King, Prof. Allen', 'Sports Complex, Auditorium'),
   ( 'MNO Institute', 'City', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1350', 'Faculty: Prof. Hill, Prof. Watson', 'Library, Labs'),
   ( 'PQR University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1380', 'Faculty: Prof. Morris, Prof. Bell', 'Research Center, Auditorium');
   select * from Matching;
   SELECT Students.name AS student_name, Colleges.name AS college_name, Students.preferences
FROM Students
INNER JOIN Matching ON Students.student_id = Matching.student_id
INNER JOIN Colleges ON Matching.college_id = Colleges.college_id
WHERE Students.age >= 18
  AND Students.gender = 'Female'
  AND Colleges.location = 'City'

ORDER BY Students.name ASC
option(maxdop 4);
 
SELECT Students.name AS student_name, Colleges.name AS college_name, Students.preferences
FROM Students
cross JOIN Colleges
WHERE Students.age >= 18
  AND Students.gender = 'Female'
  AND Colleges.location = 'City'

ORDER BY Students.name ASC
option(maxdop 1);


-- Insert values into Matching table
INSERT INTO Matching (student_id, college_id, match_score)
VALUES
   (31, 1, 90.5),
   (32, 2, 87.2),
   (33, 3, 92.8),
   (34, 4, 88.9),
   (35, 5, 95.1),
   (36, 6, 91.7),
   (37, 7, 89.3),
   (38, 8, 93.2),
   (39, 9, 90.1),
   (20, 10, 94.5),
   (21, 11, 88.7),
   (42, 12, 92.3),
   (43, 13, 90.9),
   (44, 14, 93.8),
   (45, 15, 89.6),
   (46, 16, 94.2),
   (47, 17, 91.5),
   (48, 18, 87.9),
   (49, 19, 92.1),
   (50, 20, 95.6),
   (51, 15, 89.8),
   (52, 16, 92.5),
   (53, 17, 88.3),
   (54, 18, 93.5),
   (55, 19, 90.3);

   -- Insert values into Matching table
INSERT INTO Matching (student_id, college_id, match_score)
VALUES
   (16, 35, 91.4),
   (17, 36, 88.2),
   (18, 37, 92.7),
   (19, 38, 89.9),
   (20, 39, 93.6),
   (21, 40, 91.2),
   (22, 45, 90.7),
   (23, 46, 87.5),
   (24, 47, 92.9),
   (25, 48, 89.7),
   (3, 59, 93.4),
   (4, 69, 91.9),
   (5, 75, 90.3),
   (6, 66, 87.9),
   (7, 67, 93.2),
   (8, 68, 90.5),
   (9, 59, 94.1),
   (10, 50, 91.6),
   (11, 55, 89.2),
   (12, 86, 93.7),
   (13, 77, 90.9),
   (14, 78, 88.5),
   (15, 65, 92.8),
   (16, 60, 89.4),
   (17, 85, 93.1),
   (18, 86, 90.3),
   (19, 87, 87.8),
   (20, 58, 92.6),
   (21, 59, 89.5),
   (22, 30, 94.3),
   (23, 35, 91.1),
   (24, 36, 88.8),
   (25, 87, 93.5);
   -- Insert records into Students table
INSERT INTO Students ( name, age, gender, contact_number, email, address, academic_records, preferences, counseling_status)
VALUES
   ( 'Sophia Adams', 18, 'Female', '1234567890', 'sophiaadams@example.com', '456 Elm St, City', 'GPA: 3.9, SAT: 1450', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Ethan Hernandez', 17, 'Male', '0987654321', 'ethanhernandez@example.com', '789 Oak St, Town', 'GPA: 3.8, SAT: 1350', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Amelia Carter', 19, 'Female', '5647382910', 'ameliacarter@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1320', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Sebastian Thompson', 18, 'Male', '9876543210', 'sebastianthompson@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1410', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Avery Wilson', 17, 'Female', '2468135790', 'averywilson@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1380', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Gabriel Lewis', 18, 'Male', '9081726354', 'gabriellewis@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1500', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Victoria Morgan', 19, 'Female', '8192736450', 'victoriamorgan@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1350', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Henry Allen', 18, 'Male', '1029384756', 'henryallen@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1430', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Lily Hill', 17, 'Female', '6574839201', 'lilyhill@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1400', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Christopher Turner', 18, 'Male', '1092837465', 'christopherturner@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1480', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Sofia Morris', 19, 'Female', '5463728190', 'sofiamorris@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1360', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Andrew King', 18, 'Male', '9283746510', 'andrewking@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1390', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Grace Bell', 17, 'Female', '1928374650', 'gracebell@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1440', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Julian Young', 18, 'Male', '3846592017', 'julianyoung@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1520', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Scarlett Reed', 19, 'Female', '9384756102', 'scarlettreed@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1370', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Leo Parker', 18, 'Male', '2948675103', 'leoparker@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1420', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Evelyn Wright', 17, 'Female', '4756102938', 'evelynwright@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1410', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Jack Allen', 18, 'Male', '7896102938', 'jackallen@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1490', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Chloe Baker', 19, 'Female', '3049586172', 'chloebaker@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1380', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Daniel Turner', 18, 'Male', '4958617032', 'danielturner@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1450', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Zoe Walker', 17, 'Female', '1234567890', 'zoewalker@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1430', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Jackson Harris', 18, 'Male', '0987654321', 'jacksonharris@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1510', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Mila Garcia', 19, 'Female', '5647382910', 'milagarcia@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1360', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Logan Adams', 18, 'Male', '9876543210', 'loganadams@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1440', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Harper Martinez', 17, 'Female', '2468135790', 'harpermartinez@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1420', 'Location: City, Specialization: Computer Science', NULL),
   ( 'Lucas Nelson', 18, 'Male', '9081726354', 'lucasnelson@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1500', 'Location: Town, Specialization: Electrical Engineering', NULL),
   ( 'Layla Cooper', 19, 'Female', '8192736450', 'laylacooper@example.com', '321 Pine St, City', 'GPA: 3.7, SAT: 1370', 'Location: City, Specialization: Civil Engineering', NULL),
   ( 'Matthew Ross', 18, 'Male', '1029384756', 'matthewross@example.com', '123 Main St, Town', 'GPA: 3.6, SAT: 1450', 'Location: Town, Specialization: Mechanical Engineering', NULL),
   ( 'Aria Hughes', 17, 'Female', '6574839201', 'ariahughes@example.com', '789 Oak St, City', 'GPA: 3.8, SAT: 1430', 'Location: City, Specialization: Computer Science', NULL),
   ( 'David Ramirez', 18, 'Male', '1092837465', 'davidramirez@example.com', '456 Elm St, Town', 'GPA: 3.9, SAT: 1510', 'Location: Town, Specialization: Electrical Engineering', NULL);
   -- Insert records into Colleges table
INSERT INTO Colleges ( name, location, programs_offered, admission_criteria, faculty_details, infrastructure_details)
VALUES
   ( 'JKM College', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1300', 'Faculty: Prof. Wilson, Prof. Thompson', 'Library, Labs'),
   ( 'LMN University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1350', 'Faculty: Prof. Davis, Prof. Moore', 'Research Center, Auditorium'),
   ( 'NOP College', 'City', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1380', 'Faculty: Prof. Harris, Prof. Adams', 'Library, Labs'),
   ( 'PQR University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1400', 'Faculty: Prof. Clark, Prof. Lewis', 'Sports Complex, Auditorium'),
   ( 'RST Institute', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1320', 'Faculty: Prof. Turner, Prof. Evans', 'Library, Labs'),
   ( 'STU University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1360', 'Faculty: Prof. Reed, Prof. Parker', 'Research Center, Auditorium'),
   ( 'UVW College', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1400', 'Faculty: Prof. Morgan, Prof. Young', 'Library, Labs'),
   ( 'VWX University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1420', 'Faculty: Prof. King, Prof. Allen', 'Sports Complex, Auditorium'),
   ( 'XYZ Institute', 'City', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1350', 'Faculty: Prof. Hill, Prof. Watson', 'Library, Labs'),
   ( 'ABC University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1380', 'Faculty: Prof. Morris, Prof. Bell', 'Research Center, Auditorium'),
   ( 'DEF College', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1400', 'Faculty: Prof. Wilson, Prof. Thompson', 'Library, Labs'),
   ( 'EFG University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1420', 'Faculty: Prof. Davis, Prof. Moore', 'Research Center, Auditorium'),
   ( 'GHI Institute', 'City', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1350', 'Faculty: Prof. Harris, Prof. Adams', 'Library, Labs'),
   ( 'HIJ University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1380', 'Faculty: Prof. Clark, Prof. Lewis', 'Sports Complex, Auditorium'),
   ( 'JKL College', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1400', 'Faculty: Prof. Turner, Prof. Evans', 'Library, Labs'),
   ( 'LMN University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1420', 'Faculty: Prof. Reed, Prof. Parker', 'Research Center, Auditorium'),
   ( 'MNO Institute', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1350', 'Faculty: Prof. Morgan, Prof. Young', 'Library, Labs'),
   ( 'NOP University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1380', 'Faculty: Prof. King, Prof. Allen', 'Sports Complex, Auditorium'),
   ( 'OPQ College', 'City', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1400', 'Faculty: Prof. Hill, Prof. Watson', 'Library, Labs'),
   ( 'PQR University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1420', 'Faculty: Prof. Morris, Prof. Bell', 'Research Center, Auditorium'),
   ( 'RST Institute', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1350', 'Faculty: Prof. Wilson, Prof. Thompson', 'Library, Labs'),
   ( 'STU University', 'Town', 'Electrical Engineering, Chemical Engineering', 'Minimum GPA: 3.3, Minimum SAT: 1380', 'Faculty: Prof. Davis, Prof. Moore', 'Research Center, Auditorium'),
   ( 'UVW College', 'City', 'Computer Science, Mechanical Engineering', 'Minimum GPA: 3.4, Minimum SAT: 1400', 'Faculty: Prof. Harris, Prof. Adams', 'Library, Labs'),
   ( 'VWX University', 'Town', 'Civil Engineering, Electrical Engineering', 'Minimum GPA: 3.5, Minimum SAT: 1420', 'Faculty: Prof. Clark, Prof. Lewis', 'Sports Complex, Auditorium'),
   ( 'XYZ Institute', 'City', 'Computer Science, Civil Engineering', 'Minimum GPA: 3.2, Minimum SAT: 1350', 'Faculty: Prof. Turner, Prof. Evans', 'Library, Labs');
