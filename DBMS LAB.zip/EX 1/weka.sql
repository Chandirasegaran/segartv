-- Create the database
CREATE DATABASE wekadb;

-- Use the database
USE wekadb;

-- Create the table
CREATE TABLE student_marks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(50),
    college_name VARCHAR(100),
    subject1_marks INT,
    subject2_marks INT,
    subject3_marks INT
);