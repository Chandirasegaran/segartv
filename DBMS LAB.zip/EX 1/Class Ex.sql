CREATE DATABASE CLASSEX;
USE CLASSEX;

CREATE TABLE EMPLOYEE (
	EMPLOYEE_NAME VARCHAR(50) PRIMARY KEY,
    STREET VARCHAR(50),
    CITY VARCHAR(50)
);

CREATE TABLE company (
  company_name VARCHAR(50) PRIMARY KEY,
  city VARCHAR(50)
);

CREATE TABLE WORKS (
  employee_name VARCHAR(50),
  company_name VARCHAR(50),
  salary DECIMAL(10, 2),
  FOREIGN KEY (employee_name) REFERENCES employee(employee_name),
  FOREIGN KEY (company_name) REFERENCES company(company_name)
);

CREATE TABLE manages (
  employee_name VARCHAR(50),
  manager_name VARCHAR(50),
  FOREIGN KEY (employee_name) REFERENCES employee(employee_name)
);

-- Inserting values into the employee table
INSERT INTO employee (employee_name, street, city)
VALUES
  ('Segar', '123 Main Street', 'New York'),
  ('Sasi', '456 Elm Street', 'Los Angeles'),
  ('Aravind', '789 Oak Street', 'Chicago'),
  ('Mukesh', '321 Pine Street', 'San Francisco'),
  ('Arul', '654 Maple Street', 'Boston');

-- Inserting values into the company table
INSERT INTO company (company_name, city)
VALUES
  ('First Bank Corporation', 'New York'),
  ('Small Bank Corporation', 'Chicago'),
  ('ABC Company', 'Los Angeles');

-- Inserting values into the works table
INSERT INTO works (employee_name, company_name, salary)
VALUES
  ('Segar', 'First Bank Corporation', 15000),
  ('Sasi', 'First Bank Corporation', 12000),
  ('Aravind', 'Small Bank Corporation', 18000),
  ('Mukesh', 'ABC Company', 10000),
  ('Arul', 'Small Bank Corporation', 14000);

-- Inserting values into the manages table
INSERT INTO manages (employee_name, manager_name)
VALUES
  ('Aravind', 'Segar'),
  ('Mukesh', 'Sasi');
  
-- A 
SELECT e.employee_name, e.city
FROM employee e
JOIN works w ON e.employee_name = w.employee_name
JOIN company c ON w.company_name = c.company_name
WHERE c.company_name = 'First Bank Corporation';

-- B
SELECT e.employee_name, e.city
FROM employee e
JOIN works w ON e.employee_name = w.employee_name
JOIN company c ON w.company_name = c.company_name
WHERE c.company_name = 'First Bank Corporation' 
and w.salary>10000;

-- C
SELECT e.employee_name, e.city
FROM employee e
JOIN works w ON e.employee_name = w.employee_name
JOIN company c ON w.company_name = c.company_name
WHERE c.company_name != 'First Bank Corporation';

-- D
SELECT e1.employee_name
FROM employee e1
JOIN works w1 ON e1.employee_name = w1.employee_name
JOIN works w2 ON w1.salary > w2.salary
JOIN company c ON w2.company_name = c.company_name
WHERE c.company_name = 'Small Bank Corporation';

-- E
SELECT c.company_name
FROM company c
WHERE NOT EXISTS (
  SELECT *
  FROM company
  WHERE company_name = 'Small Bank Corporation' AND city NOT IN (
    SELECT city
    FROM company
    WHERE company_name = c.company_name
  )
);

-- F
SELECT c.company_name
FROM company c
JOIN works w ON c.company_name = w.company_name
GROUP BY c.company_name
HAVING COUNT(*) = (
  SELECT MAX(emp_count)
  FROM (
    SELECT COUNT(*) as emp_count
    FROM works
    GROUP BY company_name
  ) AS counts
);

-- G

SELECT c.company_name
FROM company c
JOIN works w ON c.company_name = w.company_name
GROUP BY c.company_name
HAVING AVG(w.salary) > (
  SELECT AVG(salary)
  FROM works
  JOIN company ON works.company_name = company.company_name
  WHERE company.company_name = 'First Bank Corporation'
);
 
 
