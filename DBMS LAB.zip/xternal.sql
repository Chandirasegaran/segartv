-- deadlock
create database external;
use external;

create table dltb 
(
	id int primary key,
    name varchar(45),
    balance int 
);

insert into dltb values (1,"segar",222), (2,"apple",333);

-- ------------------------------------------------------------------

-- XML

create table xmltb
(
	id int primary key,
    name varchar(50)
);

load xml infile "xmldb.xml"
into table xmltb
rows identified by '<abc>';

select *from xmltb;


-- ----------------------------------------------
use external;

create table studreg(studname varchar(50), regno int primary key);
select *from studreg;
drop table phptb;

create database ed1;
create database ed2;
use ed1;
use ed2;

-- Create table in school1 database
CREATE TABLE school1_students (
    rollno INT PRIMARY KEY,
    name VARCHAR(50),
    school_name VARCHAR(100),
    std INT,
    percentage DECIMAL(5, 2)
);

-- Insert 10 sample records into school1_students table
INSERT INTO school1_students (rollno, name, school_name, std, percentage) VALUES
(1, 'John Doe', 'School One', 10, 89.50),
(2, 'Jane Smith', 'School One', 9, 95.20),
(3, 'Michael Johnson', 'School One', 11, 78.30),
-- Add more records here...
(10, 'Emily Brown', 'School One', 12, 92.80);
select *from school1_students;

-- Create table in school2 database
CREATE TABLE school2_students (
    rollno INT PRIMARY KEY,
    name VARCHAR(50),
    school_name VARCHAR(100),
    std INT,
    percentage DECIMAL(5, 2)
);

-- Insert 10 sample records into school2_students table
INSERT INTO school2_students (rollno, name, school_name, std, percentage) VALUES
(101, 'Mark Davis', 'School Two', 9, 86.70),
(102, 'Emma Wilson', 'School Two', 10, 91.40),
(103, 'Chris Lee', 'School Two', 11, 79.10),
-- Add more records here...
(110, 'Sophia Johnson', 'School Two', 12, 88.90);
select *from ed2.school2_students;

-- Alter table in school1 database to add the new column
ALTER TABLE ed1.school1_students
ADD address VARCHAR(200);
-- Alter table in school2 database to add the new column
ALTER TABLE ed2.school2_students
ADD address VARCHAR(200);
-- Rename the column in school1_students table
ALTER TABLE ed1.school1_students
CHANGE COLUMN address age INT;
-- Rename the column in school2_students table
ALTER TABLE ed2.school2_students
CHANGE COLUMN address age INT;


-- Query to fetch all data 
SELECT * FROM ed1.school1_students
union all 
SELECT * FROM ed2.school2_students;

-- Query to find the top 3 students with the highest percentage in School One (school1)
SELECT * FROM
    ed1.school1_students
WHERE
    school_name = 'School One'
ORDER BY
    percentage DESC
LIMIT 3;

-- to show the top 3 among all the schools
select *from 
ed1.school1_students union select * from ed2.school2_students order by percentage desc limit 3;


