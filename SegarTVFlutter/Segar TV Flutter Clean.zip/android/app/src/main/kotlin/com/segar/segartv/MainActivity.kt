package com.segar.segartv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
